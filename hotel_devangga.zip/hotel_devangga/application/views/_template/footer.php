<footer class="footer fixed-bottom bg-dark text-center text-white">
    <small>Copyright 2022 © nama siswa</small>
</footer>